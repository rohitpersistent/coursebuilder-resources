**********
Dispersion
**********

.. automodule:: networkx.algorithms.centrality

Dispersion
----------
.. autosummary::
   :toctree: generated/

   dispersion
